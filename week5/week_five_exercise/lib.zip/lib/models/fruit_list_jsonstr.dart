 String jsonString = """[
  {
    "fruit name": "bananas",
    "image name": "bananas.png",
    "color": "yellow",
    "isFavourite": true
  },
  {
    "fruit name": "strawberries",
    "image name": "strawberries.jpeg",
    "color": "red",
    "isFavourite": true
  },
  {
    "fruit name": "grapes",
    "image name": "grapes.jpeg",
    "color": "green",
    "isFavourite": false
  },
  {
    "fruit name": "apples",
    "image name": "apples.jpeg",
    "color": "red",
    "isFavourite": false
  },
  {
    "fruit name": "watermelon",
    "image name": "watermelon.jpeg",
    "color": "green",
    "isFavourite": true
  },
  {
    "fruit name": "oranges",
    "image name": "oranges.jpeg",
    "color": "orange",
    "isFavourite": false
  },
  {
    "fruit name": "blueberries",
    "image name": "blueberries.jpeg",
    "color": "blue",
    "isFavourite": true
  },
  {
    "fruit name": "lemons",
    "image name": "lemons.jpeg",
    "color": "yellow",
    "isFavourite": false
  },
  {
    "fruit name": "pineapple",
    "image name": "pineapples.jpeg",
    "color": "yellow",
    "isFavourite": false
  },
  {
    "fruit name": "cherries",
    "image name": "cherries.jpeg",
    "color": "red",
    "isFavourite": false
  },
  {
    "fruit name": "cantaloupe",
    "image name": "cantaloupe.jpeg",
    "color": "orange",
    "isFavourite": true
  },
  {
    "fruit name": "raspberries",
    "image name": "raspberries.jpeg",
    "color": "red",
    "isFavourite": false
  },
  {
    "fruit name": "pears",
    "image name": "pears.jpeg",
    "color": "green",
    "isFavourite": false
  },
  {
    "fruit name": "limes",
    "image name": "limes.jpeg",
    "color": "green",
    "isFavourite": false
  },
  {
    "fruit name": "blackberries",
    "image name": "blackberries.png",
    "color": "purple",
    "isFavourite": true
  },
  {
    "fruit name": "clementines",
    "image name": "clementines.jpeg",
    "color": "orange",
    "isFavourite": false
  },
  {
    "fruit name": "mangoes",
    "image name": "mangoes.jpeg",
    "color": "orange",
    "isFavourite": true
  },
  {
    "fruit name": "plums",
    "image name": "plums.jpeg",
    "color": "orange",
    "isFavourite": false
  }
]""";
